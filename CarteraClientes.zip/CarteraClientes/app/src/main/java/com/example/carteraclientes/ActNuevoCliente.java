package com.example.carteraclientes;

import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.Toast;
import BaseDatos.DatosOpenHelper;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.ui.AppBarConfiguration;

import com.example.carteraclientes.databinding.ActNuevoClienteBinding;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import BaseDatos.DatosOpenHelper;

public class ActNuevoCliente extends AppCompatActivity {

    private AppBarConfiguration appBarConfiguration;
    private ActNuevoClienteBinding binding;
    private FloatingActionButton fab;
    private EditText editNombre;
    private EditText editDireccion;
    private EditText editEmail;
    private EditText editTelefono;

    private SQLiteDatabase conexion;
    private DatosOpenHelper datosOpenHelper;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActNuevoClienteBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.toolbar);
        FloatingActionButton fab = findViewById(R.id.fab);

        editNombre = (EditText) findViewById(R.id.editNombre);
        editDireccion = (EditText) findViewById(R.id.editDireccion);
        editEmail = (EditText) findViewById(R.id.editEmail);
        editTelefono = (EditText) findViewById(R.id.editTelefono);
    }

    @Override
    public boolean onCreateOptionsMenu (Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_act_nuevo_cliente, menu);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch (id){
            case R.id.action_ok:
                if(bCamposCorrectos()){
                    try {
                        datosOpenHelper = new DatosOpenHelper(this);
                        conexion = datosOpenHelper.getWritableDatabase();
                        StringBuilder sql = new StringBuilder();
                        sql.append("INSERT INTO CLIENTE (NOMBRE, DIRECCION, EMAIL, TELEFONO) VALUES ('");
                        sql.append(editNombre.getText().toString().trim() + "', '");
                        sql.append(editDireccion.getText().toString().trim() + "', '");
                        sql.append(editEmail.getText().toString().trim() + "', '");
                        sql.append(editTelefono.getText().toString().trim() + "')");
                        conexion.execSQL(sql.toString());
                        conexion.close();

                        finish();
                        } catch (Exception ex) {
                            AlertDialog.Builder dlg = new AlertDialog.Builder(this);
                            dlg.setTitle("Aviso");
                            dlg.setMessage(ex.getMessage());
                            dlg.setNeutralButton("OK", null);
                            dlg.show();
                        }
                    }
                    else {
                        AlertDialog.Builder dlg = new AlertDialog.Builder(this);
                        dlg.setTitle("Aviso");
                        dlg.setMessage("Existen campos vacios");
                        dlg.setNeutralButton("OK", null);
                        dlg.show();
                    }

                //Toast.makeText(this, "Boton Ok seleccionado", Toast.LENGTH_SHORT).show();
                break;
            case R.id.action_cancelar:
                //Toast.makeText(this, "Boton Cancelar seleccionado", Toast.LENGTH_SHORT).show();
                finish();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    private boolean bCamposCorrectos(){
        boolean res = true;
        if (editNombre.getText().toString().trim().isEmpty()){
            editNombre.requestFocus();
            res = false;
        }
        if (editDireccion.getText().toString().trim().isEmpty()){
            editNombre.requestFocus();
            res = false;
        }
        if (editEmail.getText().toString().trim().isEmpty()){
            editNombre.requestFocus();
            res = false;
        }
        if (editTelefono.getText().toString().trim().isEmpty()){
            editNombre.requestFocus();
            res = false;
        }
        return res;
    }
}
